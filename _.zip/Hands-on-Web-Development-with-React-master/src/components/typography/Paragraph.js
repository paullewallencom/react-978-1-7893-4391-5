import React from 'react';
import styled from 'styled-components';

export default styled.p`
  color: ${props => props.theme.colors.text};
`;
