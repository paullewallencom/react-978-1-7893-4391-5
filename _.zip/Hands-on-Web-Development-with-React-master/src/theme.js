export default {
  colors: {
    primary: 'royalblue',
    secondary: 'crimson',
    text: 'gray',
  }
};
