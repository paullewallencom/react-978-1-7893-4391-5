export default [
  { label: '05/2018', views: 8331, clicks: 121 },
  { label: '06/2018', views: 7301, clicks: 611 },
  { label: '07/2018', views: 7122, clicks: 429 },
  { label: '08/2018', views: 9123, clicks: 882 },
  { label: '09/2018', views: 12013, clicks: 2035 },
  { label: '10/2018', views: 6911, clicks: 653 }
];



