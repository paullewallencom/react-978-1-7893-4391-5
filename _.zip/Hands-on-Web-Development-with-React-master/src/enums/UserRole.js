export default {
  ANONYMOUS: 0,
  USER: 1,
  ADMIN: 2,
};
